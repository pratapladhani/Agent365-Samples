# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""
Custom Observability Instrumentation for Admin Agent

This module provides custom spans and telemetry for calendar operations
to enhance observability beyond the automatic Agent Framework instrumentation.
"""

import functools
import logging
from typing import Any, Callable, Dict, Optional
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

logger = logging.getLogger(__name__)

# Get tracer for admin agent
tracer = trace.get_tracer("admin_agent")


def trace_calendar_operation(operation_name: str):
    """
    Decorator to add custom observability span for calendar operations.
    
    Args:
        operation_name: Name of the calendar operation (e.g., "verify_access", "accept_meeting")
    
    Usage:
        @trace_calendar_operation("verify_delegated_access")
        async def verify_access(self, user_email: str):
            # Your code here
            pass
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Create custom span
            with tracer.start_as_current_span(
                f"calendar.{operation_name}",
                attributes={
                    "calendar.operation": operation_name,
                    "admin_agent.component": "calendar_management"
                }
            ) as span:
                try:
                    # Add function arguments as span attributes
                    if kwargs:
                        for key, value in kwargs.items():
                            if isinstance(value, (str, int, float, bool)):
                                span.set_attribute(f"calendar.{key}", value)
                    
                    # Execute the function
                    result = await func(*args, **kwargs)
                    
                    # Mark span as successful
                    span.set_status(Status(StatusCode.OK))
                    span.set_attribute("calendar.operation.success", True)
                    
                    # Add result metadata if available
                    if isinstance(result, dict):
                        if "status" in result:
                            span.set_attribute("calendar.operation.status", result["status"])
                        if "event_id" in result:
                            span.set_attribute("calendar.event_id", result["event_id"])
                    
                    return result
                    
                except Exception as e:
                    # Record exception in span
                    span.record_exception(e)
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("calendar.operation.success", False)
                    span.set_attribute("calendar.operation.error", str(e))
                    
                    logger.error(f"Calendar operation {operation_name} failed: {e}", exc_info=True)
                    raise
        
        return wrapper
    return decorator


def trace_workflow_execution(workflow_name: str):
    """
    Decorator to add custom span for workflow execution.
    
    Args:
        workflow_name: Name of the workflow (e.g., "auto_accept", "find_meeting_time")
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            with tracer.start_as_current_span(
                f"workflow.{workflow_name}",
                attributes={
                    "workflow.name": workflow_name,
                    "admin_agent.component": "workflow_engine"
                }
            ) as span:
                try:
                    result = await func(*args, **kwargs)
                    
                    span.set_status(Status(StatusCode.OK))
                    
                    # Add workflow result metadata
                    if isinstance(result, dict):
                        if "status" in result:
                            span.set_attribute("workflow.status", result["status"])
                        if "resolved_conflicts" in result:
                            span.set_attribute("workflow.conflicts_resolved", result["resolved_conflicts"])
                        if "event_id" in result:
                            span.set_attribute("workflow.created_event", result["event_id"])
                    
                    return result
                    
                except Exception as e:
                    span.record_exception(e)
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    logger.error(f"Workflow {workflow_name} failed: {e}", exc_info=True)
                    raise
        
        return wrapper
    return decorator


def create_calendar_span(
    operation: str,
    delegated_user: Optional[str] = None,
    event_id: Optional[str] = None,
    additional_attributes: Optional[Dict[str, Any]] = None
):
    """
    Context manager to create a custom calendar operation span.
    
    Usage:
        with create_calendar_span("accept_meeting", delegated_user="user@contoso.com", event_id="evt123"):
            # Your calendar operation code here
            pass
    """
    attributes = {
        "calendar.operation": operation,
        "admin_agent.component": "calendar_management"
    }
    
    if delegated_user:
        attributes["calendar.delegated_user"] = delegated_user
    if event_id:
        attributes["calendar.event_id"] = event_id
    if additional_attributes:
        attributes.update(additional_attributes)
    
    return tracer.start_as_current_span(
        f"calendar.{operation}",
        attributes=attributes
    )


def log_calendar_event(
    operation: str,
    status: str,
    delegated_user: Optional[str] = None,
    event_details: Optional[Dict[str, Any]] = None
):
    """
    Log a calendar event with structured logging for observability.
    
    Args:
        operation: Calendar operation name
        status: Operation status ("success", "error", "pending")
        delegated_user: Email of delegated user
        event_details: Additional event details
    """
    log_data = {
        "operation": operation,
        "status": status,
        "component": "admin_agent.calendar"
    }
    
    if delegated_user:
        log_data["delegated_user"] = delegated_user
    
    if event_details:
        log_data.update(event_details)
    
    if status == "error":
        logger.error(f"Calendar operation failed", extra=log_data)
    else:
        logger.info(f"Calendar operation: {operation}", extra=log_data)


# Telemetry configuration helper
class TelemetryConfig:
    """Configuration for Agent 365 observability"""
    
    @staticmethod
    def is_observability_enabled() -> bool:
        """Check if observability is enabled"""
        import os
        return os.getenv("ENABLE_OBSERVABILITY", "true").lower() == "true"
    
    @staticmethod
    def is_sensitive_data_enabled() -> bool:
        """Check if sensitive data logging is enabled"""
        import os
        return os.getenv("ENABLE_SENSITIVE_DATA", "false").lower() == "true"
    
    @staticmethod
    def get_service_name() -> str:
        """Get service name for observability"""
        import os
        return os.getenv("OBSERVABILITY_SERVICE_NAME", "admin-agent")
    
    @staticmethod
    def get_service_namespace() -> str:
        """Get service namespace"""
        import os
        return os.getenv("OBSERVABILITY_SERVICE_NAMESPACE", "agent365.samples")


# Example usage in agent code:
"""
from telemetry.observability import trace_calendar_operation, create_calendar_span

class AdminAgent:
    @trace_calendar_operation("accept_meeting")
    async def accept_meeting(self, event_id: str, comment: str = None):
        # Your implementation
        pass
    
    async def check_calendar(self, user: str):
        with create_calendar_span("check_calendar", delegated_user=user):
            # Your calendar check code
            pass
"""
