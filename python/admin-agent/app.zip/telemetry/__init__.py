# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""
Telemetry package for Admin Agent observability

This package provides:
- Custom span decorators for calendar operations
- Workflow execution tracing
- Structured logging helpers
- Telemetry configuration
"""

from .observability import (
    trace_calendar_operation,
    trace_workflow_execution,
    create_calendar_span,
    log_calendar_event,
    TelemetryConfig
)

__all__ = [
    "trace_calendar_operation",
    "trace_workflow_execution",
    "create_calendar_span",
    "log_calendar_event",
    "TelemetryConfig"
]
